package geometries;

import primitives.*;

/** A class that represents a plane */
public class Plane implements Geometry {

    final private Point q;
    final private Vector normal;

    /**
     * Constructor with parameters
     */
    public Plane(Point q, Vector normal) {
        this.q = q;
        this.normal = normal.normalize();
    }

    /**
     * Builder that gets points
     */
    public Plane(Point q1, Point q2, Point q3) {
        normal = null;
        q = q1;
    }

    /**
     * Getter for normal
     * @return the normal vector
     */
    public Vector getNormal() {
        return normal;
    }

    @Override
    public Vector getNormal(Point point) {
        return  normal;
    }
}